| dataset | mode | calibration | TPR@1%FPR | p95_ms | p99_ms | eps |
|---|---|---|---|---|---|---|
| synth_tokens | baseline | conformal | 1.0000 | 3.2 | 3.4 | 328.5 |
| synth_tokens | baseline | no_calib | 1.0000 | 8.0 | 8.5 | 135.9 |
| synth_tokens | transformer | conformal | 0.9833 | 1.6 | 1.9 | 731.6 |
| synth_tokens | transformer | no_calib | 0.9833 | 1.5 | 1.7 | 782.3 |
| mini_tokens | baseline | conformal | NA | 7.4 | 7.4 | 119.0 |
| mini_tokens | baseline | no_calib | NA | 7.7 | 7.7 | 112.8 |
| mini_tokens | transformer | conformal | NA | 1.5 | 1.5 | 454.6 |
| mini_tokens | transformer | no_calib | NA | 1.6 | 1.6 | 427.1 |
