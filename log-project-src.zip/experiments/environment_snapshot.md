# Environment snapshot — 2025-08-25

**CPU**

Name                                             NumberOfCores NumberOfLogicalProces
                                                                                sors
----                                             ------------- ---------------------
AMD Ryzen 7 5800HS with Radeon Graphics                      8                    16

**Memory**
TotalPhysicalMemoryBytes=16541495296 (~15.41 GB)

**OS**

OsName                    OsVersion  OsBuildNumber
------                    ---------  -------------
Microsoft Windows 11 Home 10.0.26100 26100

**Docker**
Client:
 Version:           28.3.2
 API version:       1.51
 Go version:        go1.24.5
 Git commit:        578ccf6
 Built:             Wed Jul  9 16:12:31 2025
 OS/Arch:           windows/amd64
 Context:           desktop-linux

Server: Docker Desktop 4.44.3 (202357)
 Engine:
  Version:          28.3.2
  API version:      1.51 (minimum version 1.24)
  Go version:       go1.24.5
  Git commit:       e77ff99
  Built:            Wed Jul  9 16:13:55 2025
  OS/Arch:          linux/amd64
  Experimental:     false
 containerd:
  Version:          1.7.27
  GitCommit:        05044ec0a9a75232cad458027ca83437aae3f4da
 runc:
  Version:          1.2.5
  GitCommit:        v1.2.5-0-g59923ef
 docker-init:
  Version:          0.19.0
  GitCommit:        de40ad0
OperatingSystem="Docker Desktop"

**Image Python/libs**
python==3.11.13
numpy==1.26.4
scikit-learn==1.5.2
matplotlib==3.9.2
psutil==7.0.0
scipy==1.16.1
